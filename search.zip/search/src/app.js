var app=angular.module('MyApp', ['ngMaterial'])

app.controller('AppCtrl', function($scope,$mdDialog) {



    $scope.todos = [
      {

        keyword: "ece",

      },
      {

        keyword: "it"

      },
      {

        keyword: "cse"

      },
      {

        keyword: 'Me'

      },
      {

        keyword: 'Mca'

      },
    ];

    $scope.showTabDialog = function(ev) {
  $mdDialog.show({
   controller:  'DialogController',
   templateUrl: 'includes/views/tab.html',
   parent: angular.element(document.body),
   targetEvent: ev,
   clickOutsideToClose: true
  })};
});

app.controller('DialogController', function($scope, $mdDialog, $rootScope) {
  $scope.searchText = "";
  $scope.a =0;
  $scope.edit_show = false;
  $scope.Person = [];
  $scope.selectedItem = [];
  $scope.isDisabled = false;
  $scope.noCache = false;
  $scope.show = false;
  $scope.show1 = false;
  $scope.showsearch=false;
  $scope.msg = "";
  $scope.flag=0;
  $scope.index=[];
  $scope.filter_show = true;
  $scope.data1 = {};
  $scope.data = {};
  $scope.relations = [
          "sub concept of",
          "example of",
          "related"
      ];
//adding more controls
$scope.rows = []; // declared rows and assigned a empty row to the scope
$scope.add_more = function () {
    $scope.a++;
    $scope.rows.push({
        subject: 'sub'+$scope.a,
        object: 'obj'+$scope.a,
        relation: 'rel'+$scope.a
    });
};
//end
    $scope.hide = function() {
      $mdDialog.hide();
    };
    $scope.cancel = function() {
      $mdDialog.cancel();
    };
$scope.answer = function(src1,tar1,rel1) {
$rootScope.$broadcast("capture", {
  src:src1, tar:tar1, rel:rel1
  })
  $mdDialog.cancel();
};
// delete function
$scope.del_func = function(del) {
$rootScope.$broadcast("del_capture", {
  delf : del
})
  $mdDialog.cancel();
};
//swap function
    $scope.swap = function(s_label,o_label){
      $scope.sub_label = o_label;
      $scope.obj_label = s_label;
    };
    $scope.swap1 = function(s_label,o_label,rel){
      $scope.sub1 = o_label;
      $scope.obj1 = s_label;
    };
//swap_function end

//edit_fun
$scope.edit_fun = function(edit){
    $scope.edit_show = true;
}
$scope.edit_change = function(sub,sub_pro,sub_pro){
  $rootScope.$broadcast("edit_capture", {
    sub : sub, sub_pro : sub_pro, sub_pro:sub_pro
  })
    $mdDialog.cancel();
}
});
